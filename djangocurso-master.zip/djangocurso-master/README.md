# djangocurso
[![Build Status](https://app.travis-ci.com/raphamoral/djangocurso.svg?branch=master)
[![Updates](https://pyup.io/repos/github/raphamoral/djangocurso/shield.svg)](https://pyup.io/repos/github/raphamoral/djangocurso/)
Aplicacão disponivel em https://pythonprodjango2523432.herokuapp.com/