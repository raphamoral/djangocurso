def test_passa():
    assert  1 == 1